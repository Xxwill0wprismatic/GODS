#!/usr/bin/env python3
"""
GODS Recon Intelligence Engine — Structured Logger
"""
import json
import os
from datetime import datetime
from utils.helpers import C, sev_rank

class ReconLogger:
    def __init__(self, target, outdir="reports"):
        self.target = target
        self.outdir = outdir
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.raw_log = []
        self.findings = []
        self.tools_used = []
        self.tools_skipped = []
        os.makedirs(outdir, exist_ok=True)

    def raw(self, module, tool, stdout, stderr="", rc=0):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "module": module,
            "tool": tool,
            "stdout": stdout,
            "stderr": stderr,
            "returncode": rc
        }
        self.raw_log.append(entry)

    def finding(self, module, title, description, severity="INFO", evidence="", remediation=""):
        finding = {
            "timestamp": datetime.now().isoformat(),
            "module": module,
            "title": title,
            "description": description,
            "severity": severity.upper(),
            "severity_rank": sev_rank(severity),
            "evidence": evidence,
            "remediation": remediation
        }
        self.findings.append(finding)
        color = {
            "CRITICAL": C.R, "HIGH": C.M, "MEDIUM": C.Y,
            "LOW": C.C, "INFO": C.D
        }.get(severity.upper(), C.W)
        print(f"  {color}[{severity.upper():8}]{C.X} {module:12} -> {title}")

    def save_raw(self):
        path = os.path.join(self.outdir, f"{self.target}_{self.session_id}_raw.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.raw_log, f, indent=2)
        return path

    def save_findings(self):
        path = os.path.join(self.outdir, f"{self.target}_{self.session_id}_findings.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.findings, f, indent=2)
        return path
