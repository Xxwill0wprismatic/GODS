#!/usr/bin/env python3
"""
GODS Module: dns
Tools: dig, host, python fallback
"""
import re
import socket
from utils.helpers import run_cmd, tool_check, C, log
from config.settings import TOOLS, TIMEOUTS, DNS_RECORD_TYPES

class DNS:
    def __init__(self, target, logger, options=None):
        self.target = target
        self.logger = logger
        self.options = options or {}

    def _prompt_options(self):
        print()
        print("DNS Recon")
        print()
        print("Available record types:", ", ".join(DNS_RECORD_TYPES))
        rt = input("[?] Record types (comma-separated, default=A,MX,NS,TXT): ").strip()
        if rt:
            types = [t.strip().upper() for t in rt.split(",")]
            valid = [t for t in types if t in DNS_RECORD_TYPES]
            invalid = [t for t in types if t not in DNS_RECORD_TYPES]
            if invalid:
                log("dns", f"Invalid record types skipped: {', '.join(invalid)}", C.Y)
            if not valid:
                log("dns", "No valid record types, using default", C.Y)
                valid = ["A", "MX", "NS", "TXT"]
        else:
            valid = ["A", "MX", "NS", "TXT"]

        wildcard = input("[?] Check wildcard DNS? (Y/n): ").strip().lower() != "n"
        zone_xfer = input("[?] Check zone transfer? (y/N): ").strip().lower() == "y"

        self.options = {
            "record_types": valid,
            "wildcard": wildcard,
            "zone_xfer": zone_xfer,
        }
        print()

    def run(self):
        if not self.options or not self.options.get("record_types"):
            self._prompt_options()

        record_types = self.options.get("record_types", ["A", "MX", "NS", "TXT"])
        wildcard = self.options.get("wildcard", True)
        zone_xfer = self.options.get("zone_xfer", False)

        log("dns", f"Querying DNS records for {self.target}", C.B)
        results = {"records": {}, "wildcard": False, "zone_xfer": False}

        has_dig = tool_check(TOOLS["dig"])
        has_host = tool_check(TOOLS["host"])
        if not has_dig:
            self.logger.tools_skipped.append("dig (not installed)")

        for rtype in record_types:
            stdout = stderr = ""
            rc = -1
            if has_dig:
                stdout, stderr, rc = run_cmd([TOOLS["dig"], "+short", rtype, self.target], timeout=TIMEOUTS["dns"])
                self.logger.raw("dns", f"dig-{rtype}", stdout, stderr, rc)
            elif has_host:
                stdout, stderr, rc = run_cmd([TOOLS["host"], "-t", rtype, self.target], timeout=TIMEOUTS["dns"])
                self.logger.raw("dns", f"host-{rtype}", stdout, stderr, rc)
                if rc == 0:
                    lines = []
                    for line in stdout.splitlines():
                        if " has " in line and " pointer " not in line.lower():
                            value = line.split(" has ", 1)[1]
                            if " " in value:
                                value = value.split(" ", 1)[1]
                            lines.append(value.strip().rstrip("."))
                    stdout = "\n".join(lines)
            else:
                if rtype == "A":
                    try:
                        stdout = socket.gethostbyname(self.target)
                        rc = 0
                    except socket.gaierror as e:
                        stderr = str(e)
                else:
                    stderr = "No DNS command available"

            if rc == 0 and stdout:
                results["records"][rtype] = [line.strip() for line in stdout.splitlines() if line.strip()]
            elif rc == 0:
                results["records"][rtype] = []
            else:
                results["records"][rtype] = []
                if stderr:
                    log("dns", f"{rtype} lookup unavailable: {stderr[:120]}", C.Y)

            vals = results["records"].get(rtype, [])
            if vals:
                for v in vals:
                    self.logger.finding("dns", f"{rtype} record", v, "INFO")
            else:
                self.logger.finding("dns", f"{rtype} record", "No record found", "INFO")

        if wildcard:
            log("dns", "Checking wildcard DNS", C.Y)
            fake = f"wildcard-test-{abs(hash(self.target)) % 100000}.{self.target}"
            try:
                socket.gethostbyname(fake)
                results["wildcard"] = True
                self.logger.finding("dns", "Wildcard DNS detected", f"{fake} resolved", "MEDIUM",
                                    "", "Wildcard DNS can obscure true subdomain enumeration results.")
            except socket.gaierror:
                results["wildcard"] = False
                self.logger.finding("dns", "Wildcard DNS", "Not detected", "INFO")

        if zone_xfer:
            if has_dig:
                log("dns", "Checking zone transfer", C.Y)
                stdout, stderr, rc = run_cmd([TOOLS["dig"], "AXFR", self.target], timeout=TIMEOUTS["dns"])
                self.logger.raw("dns", "dig-axfr", stdout, stderr, rc)
                if rc == 0 and stdout and "; Transfer failed" not in stdout:
                    results["zone_xfer"] = True
                    self.logger.finding("dns", "Zone transfer allowed", "AXFR succeeded", "CRITICAL",
                                        stdout[:500], "Disable zone transfers on DNS servers.")
                else:
                    results["zone_xfer"] = False
                    self.logger.finding("dns", "Zone transfer", "Not allowed", "INFO")
            else:
                log("dns", "Cannot check zone transfer without dig", C.Y)
                self.logger.finding("dns", "Zone transfer", "Skipped (dig missing)", "INFO")

        log("dns", "DNS recon complete.", C.G)
        return results
