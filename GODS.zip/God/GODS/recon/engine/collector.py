#!/usr/bin/env python3
"""
GODS Engine: collector
Orchestrates all recon modules and collects raw output.
"""
import time
from utils.helpers import C, log, banner
from utils.logger import ReconLogger

from modules.portscan.portscan import PortScan
from modules.webscan.webscan import WebScan
from modules.dns.dns import DNS
from modules.tls.tls import TLS
from modules.headers.headers import Headers
from modules.whois.whois import Whois
from modules.subdomain.subdomain import Subdomain
from modules.techdetect.techdetect import TechDetect
from modules.wafdetect.wafdetect import WAFDetect
from modules.certtransparency.certtransparency import CertTransparency

class Collector:
    def __init__(self, target, logger, modules=None, wordlist=None, tls_port=443,
                 portscan_opts=None, webscan_opts=None, dns_opts=None,
                 tls_opts=None, headers_opts=None, whois_opts=None,
                 subdomain_opts=None, techdetect_opts=None, wafdetect_opts=None,
                 certtransparency_opts=None):
        self.target = target
        self.logger = logger
        self.wordlist = wordlist
        self.tls_port = tls_port
        self.portscan_opts = portscan_opts or {}
        self.webscan_opts = webscan_opts or {}
        self.dns_opts = dns_opts or {}
        self.tls_opts = tls_opts or {}
        self.headers_opts = headers_opts or {}
        self.whois_opts = whois_opts or {}
        self.subdomain_opts = subdomain_opts or {}
        self.techdetect_opts = techdetect_opts or {}
        self.wafdetect_opts = wafdetect_opts or {}
        self.certtransparency_opts = certtransparency_opts or {}
        self.results = {}
        self.modules = modules or [
            "portscan", "webscan", "dns", "tls", "headers",
            "whois", "subdomain", "techdetect", "wafdetect", "certtransparency"
        ]

    def run(self):
        banner()
        log("ENGINE", f"Target: {self.target}", C.G)
        log("ENGINE", f"Modules: {', '.join(self.modules)}", C.G)
        print()

        start = time.time()

        if "portscan" in self.modules:
            log("ENGINE", "--- Port Scan ---", C.B)
            self.results["portscan"] = PortScan(self.target, self.logger, self.portscan_opts).run()
            print()

        if "dns" in self.modules:
            log("ENGINE", "--- DNS Recon ---", C.B)
            self.results["dns"] = DNS(self.target, self.logger, self.dns_opts).run()
            print()

        if "subdomain" in self.modules:
            log("ENGINE", "--- Subdomain Enum ---", C.B)
            self.results["subdomain"] = Subdomain(self.target, self.logger, self.subdomain_opts).run()
            print()

        if "certtransparency" in self.modules:
            log("ENGINE", "--- Cert Transparency ---", C.B)
            self.results["certtransparency"] = CertTransparency(self.target, self.logger, self.certtransparency_opts).run()
            print()

        if "whois" in self.modules:
            log("ENGINE", "--- WHOIS Lookup ---", C.B)
            self.results["whois"] = Whois(self.target, self.logger, self.whois_opts).run()
            print()

        if "webscan" in self.modules:
            log("ENGINE", "--- Web Path Scan ---", C.B)
            self.results["webscan"] = WebScan(self.target, self.logger, self.webscan_opts).run()
            print()

        if "techdetect" in self.modules:
            log("ENGINE", "--- Tech Detection ---", C.B)
            self.results["techdetect"] = TechDetect(self.target, self.logger, self.techdetect_opts).run()
            print()

        if "wafdetect" in self.modules:
            log("ENGINE", "--- WAF Detection ---", C.B)
            self.results["wafdetect"] = WAFDetect(self.target, self.logger, self.wafdetect_opts).run()
            print()

        if "tls" in self.modules:
            log("ENGINE", "--- TLS Analysis ---", C.B)
            self.results["tls"] = TLS(self.target, self.logger, self.tls_opts).run()
            print()

        if "headers" in self.modules:
            log("ENGINE", "--- Header Security ---", C.B)
            self.results["headers"] = Headers(self.target, self.logger, self.headers_opts).run()
            print()

        elapsed = time.time() - start
        log("ENGINE", f"Collection complete in {elapsed:.1f}s", C.G)
        return self.results
