#!/usr/bin/env python3
"""GODS Recon external-tool registry and safe interactive runner.

The registry contains exactly 30 optional integrations. A tool is considered
available only when its executable is present (or, for the small built-in HTTP
checks, when the Python runtime can perform the check).
"""
from __future__ import annotations

import os
import shlex
import shutil
import subprocess
from dataclasses import dataclass
from typing import Callable, Optional
from urllib.parse import urlparse

from utils.helpers import C


@dataclass(frozen=True)
class ToolSpec:
    name: str
    command: Optional[str]
    category: str
    description: str
    builder: Callable[[str, dict], list[str]]
    needs_url: bool = False


def _url(target: str) -> str:
    target = str(target).strip()
    if target.startswith(("http://", "https://")):
        return target.rstrip("/")
    return "https://" + target.rstrip("/")


def _host(target: str) -> str:
    parsed = urlparse(_url(target))
    return parsed.hostname or target.split("/")[0].split(":")[0]


def _positive_int(value, default, minimum=1, maximum=100000):
    try:
        n = int(str(value).strip())
    except (TypeError, ValueError):
        return default
    return max(minimum, min(n, maximum))


def _port_value(value, default=443):
    return _positive_int(value, default, 1, 65535)


def _port_spec(value, default="80,443"):
    value = str(value or "").strip()
    if not value:
        return default
    # Accept comma-separated ports and ranges such as 80,443,8000-8080.
    for part in value.split(","):
        part = part.strip()
        if not part:
            return default
        if "-" in part:
            a, b = part.split("-", 1)
            if not (a.isdigit() and b.isdigit() and 1 <= int(a) <= int(b) <= 65535):
                return default
        elif not (part.isdigit() and 1 <= int(part) <= 65535):
            return default
    return value


def _nmap(target, o):
    cmd = ["nmap"]
    mode = o.get("ports", "common")
    ports = {"common": "21,22,25,53,80,110,139,143,443,445,3389,8080", "top": "--top-ports 100"}
    if mode == "custom":
        cmd += ["-p", _port_spec(o.get("custom_ports"), "80,443")]
    elif mode == "top":
        cmd += ["--top-ports", str(_positive_int(o.get("top_n"), 100, 1, 65535))]
    elif mode == "all":
        cmd += ["-p-"]
    else:
        cmd += ["-p", ports["common"]]
    if o.get("service", True): cmd.append("-sV")
    if o.get("udp", False): cmd.append("-sU")
    timing = str(o.get("timing", "-T3"))
    if timing in {"-T0", "-T1", "-T2", "-T3", "-T4", "-T5"}:
        cmd.append(timing)
    return cmd + [_host(target)]


def _masscan(target, o):
    return ["masscan", _host(target), "-p", _port_spec(o.get("custom_ports"), "80,443"),
            "--rate", str(_positive_int(o.get("rate"), 100, 1, 1000000))]


def _rustscan(target, o):
    cmd = ["rustscan", "-a", _host(target), "--ulimit", str(o.get("ulimit", 5000))]
    if o.get("ports"): cmd += ["-p", _port_spec(o["ports"])]
    return cmd


def _naabu(target, o):
    cmd = ["naabu", "-host", _host(target)]
    if o.get("ports"): cmd += ["-p", _port_spec(o["ports"])]
    else: cmd += ["-top-ports", str(_positive_int(o.get("top_n"), 100, 1, 10000))]
    return cmd


def _httpx(target, o):
    cmd = ["httpx", "-u", _url(target), "-silent"]
    if o.get("status", True): cmd.append("-status-code")
    if o.get("title", True): cmd.append("-title")
    if o.get("tech", True): cmd.append("-tech-detect")
    return cmd


def _curl(target, o):
    cmd = ["curl", "-L" if o.get("redirects", True) else "-I", "-sS", "-D", "-", "-o", os.devnull, _url(target)]
    if "-I" not in cmd: cmd.insert(1, "-I")
    return cmd


def _wget(target, o):
    return ["wget", "--server-response", "--spider", _url(target)]


def _whatweb(target, o):
    return ["whatweb", "--no-errors", _url(target)]


def _nikto(target, o):
    return ["nikto", "-h", _url(target), "-nointeractive"]


def _nuclei(target, o):
    cmd = ["nuclei", "-u", _url(target), "-silent", "-rate-limit", str(o.get("rate", 10))]
    if o.get("severity"): cmd += ["-severity", o["severity"]]
    return cmd


def _gobuster(target, o):
    cmd = ["gobuster", "dir", "-u", _url(target), "-q"]
    cmd += ["-w", o.get("wordlist", "")]
    if o.get("extensions"): cmd += ["-x", o["extensions"]]
    cmd += ["-t", str(o.get("threads", 10))]
    return cmd


def _ffuf(target, o):
    return ["ffuf", "-u", _url(target).rstrip("/") + "/FUZZ", "-w", o.get("wordlist", ""), "-mc", "200,204,301,302,307,401,403", "-t", str(o.get("threads", 10)), "-s"]


def _feroxbuster(target, o):
    cmd = ["feroxbuster", "-u", _url(target), "--quiet", "-t", str(o.get("threads", 10))]
    if o.get("wordlist"): cmd += ["-w", o["wordlist"]]
    return cmd


def _dirsearch(target, o):
    cmd = ["dirsearch", "-u", _url(target), "--format", "plain"]
    if o.get("wordlist"): cmd += ["-w", o["wordlist"]]
    return cmd


def _wfuzz(target, o):
    return ["wfuzz", "-c", "-z", f"file,{o.get('wordlist','')}", "--hc", "404", _url(target).rstrip("/") + "/FUZZ"]


def _gau(target, o):
    return ["gau", _host(target)]


def _waybackurls(target, o):
    return ["waybackurls", _host(target)]


def _hakrawler(target, o):
    return ["hakrawler", "-url", _url(target), "-depth", str(o.get("depth", 2)), "-plain"]


def _katana(target, o):
    return ["katana", "-u", _url(target), "-silent", "-depth", str(o.get("depth", 2))]


def _subfinder(target, o):
    return ["subfinder", "-d", _host(target), "-silent"]


def _amass(target, o):
    return ["amass", "enum", "-passive", "-d", _host(target)]


def _dnsx(target, o):
    return ["dnsx", "-d", _host(target), "-a", "-aaaa", "-mx", "-ns", "-txt", "-silent"]


def _dig(target, o):
    return ["dig", _host(target), o.get("record", "A"), "+short"]


def _hostcmd(target, o):
    return ["host", _host(target)]


def _whois(target, o):
    return ["whois", _host(target)]


def _wafw00f(target, o):
    return ["wafw00f", _url(target)]


def _openssl(target, o):
    host = _host(target)
    port = str(o.get("port", 443))
    return ["openssl", "s_client", "-connect", f"{host}:{port}", "-servername", host, "-brief"]


def _sslscan(target, o):
    return ["sslscan", f"{_host(target)}:{o.get('port', 443)}"]


def _testssl(target, o):
    return ["testssl.sh", "--quiet", _url(target)]


def _zap(target, o):
    # zap-cli syntax varies between releases; keep this adapter conservative.
    return ["zap-cli", "quick-scan", _url(target)]


TOOL_LIST = [
    ToolSpec("nmap", "nmap", "Network", "Port and service discovery", _nmap),
    ToolSpec("rustscan", "rustscan", "Network", "Fast port discovery", _rustscan),
    ToolSpec("masscan", "masscan", "Network", "High-speed TCP port scanner", _masscan),
    ToolSpec("naabu", "naabu", "Network", "Port discovery", _naabu),
    ToolSpec("httpx", "httpx", "HTTP", "HTTP probing and fingerprinting", _httpx),
    ToolSpec("curl", "curl", "HTTP", "HTTP header/status inspection", _curl, True),
    ToolSpec("wget", "wget", "HTTP", "HTTP response inspection", _wget, True),
    ToolSpec("whatweb", "whatweb", "Web", "Web technology fingerprinting", _whatweb, True),
    ToolSpec("nikto", "nikto", "Web", "Web server security checks", _nikto, True),
    ToolSpec("nuclei", "nuclei", "Web", "Template-based security checks", _nuclei, True),
    ToolSpec("gobuster", "gobuster", "Discovery", "Directory and file discovery", _gobuster, True),
    ToolSpec("ffuf", "ffuf", "Discovery", "Web fuzzing", _ffuf, True),
    ToolSpec("feroxbuster", "feroxbuster", "Discovery", "Content discovery", _feroxbuster, True),
    ToolSpec("dirsearch", "dirsearch", "Discovery", "Web path discovery", _dirsearch, True),
    ToolSpec("wfuzz", "wfuzz", "Discovery", "Web fuzzing", _wfuzz, True),
    ToolSpec("gau", "gau", "URLs", "Known URL collection", _gau),
    ToolSpec("waybackurls", "waybackurls", "URLs", "Wayback URL collection", _waybackurls),
    ToolSpec("hakrawler", "hakrawler", "URLs", "Link crawling", _hakrawler, True),
    ToolSpec("katana", "katana", "URLs", "Modern web crawling", _katana, True),
    ToolSpec("subfinder", "subfinder", "Domains", "Passive subdomain enumeration", _subfinder),
    ToolSpec("amass", "amass", "Domains", "Passive asset enumeration", _amass),
    ToolSpec("dnsx", "dnsx", "DNS", "DNS resolution and records", _dnsx),
    ToolSpec("dig", "dig", "DNS", "DNS record lookup", _dig),
    ToolSpec("host", "host", "DNS", "DNS host lookup", _hostcmd),
    ToolSpec("whois", "whois", "Domain", "WHOIS lookup", _whois),
    ToolSpec("wafw00f", "wafw00f", "Web", "WAF fingerprinting", _wafw00f, True),
    ToolSpec("openssl", "openssl", "TLS", "TLS certificate/handshake inspection", _openssl),
    ToolSpec("sslscan", "sslscan", "TLS", "TLS configuration inspection", _sslscan),
    ToolSpec("testssl.sh", "testssl.sh", "TLS", "TLS configuration analysis", _testssl, True),
    ToolSpec("zap-cli", "zap-cli", "Web", "OWASP ZAP command-line integration", _zap, True),
]

assert len(TOOL_LIST) == 30
TOOL_INDEX = {t.name: t for t in TOOL_LIST}


def _tool_available(spec: ToolSpec) -> bool:
    """Detect the expected executable, not just an unrelated same-named binary."""
    if not spec.command or not shutil.which(spec.command):
        return False
    if spec.name == "httpx":
        # ProjectDiscovery httpx exposes these flags; Python's httpx CLI does not.
        try:
            p = subprocess.run([spec.command, "-h"], capture_output=True, text=True,
                               timeout=5, errors="replace")
            text = (p.stdout or "") + (p.stderr or "")
            return "-status-code" in text or "-tech-detect" in text
        except Exception:
            return False
    return True


def availability() -> dict[str, bool]:
    return {t.name: _tool_available(t) for t in TOOL_LIST}


def print_tool_catalog() -> None:
    status = availability()
    print()
    print("GODS Recon Tools")
    print()
    current = None
    for i, spec in enumerate(TOOL_LIST, 1):
        if spec.category != current:
            current = spec.category
            print(f"{current}")
        mark = f"{C.G}[OK]{C.X}" if status[spec.name] else f"{C.R}[MISS]{C.X}"
        print(f"  {i:02d}. {spec.name:<14} {mark}  {spec.description}")
    print()
    print("[OK] installed   [MISS] not installed")


def _ask_common(spec: ToolSpec) -> dict:
    """Collect validated, tool-specific options without crashing on bad input."""
    o = {}

    def ask_int(prompt, default, minimum, maximum):
        raw = input(prompt).strip()
        if not raw:
            return default
        try:
            value = int(raw)
        except ValueError:
            raise ValueError(f"invalid number: {raw}")
        if not minimum <= value <= maximum:
            raise ValueError(f"value must be between {minimum} and {maximum}")
        return value

    if spec.name == "nmap":
        print("Nmap options: common, top, custom, all")
        mode = input("[?] Ports mode [common]: ").strip().lower() or "common"
        if mode not in {"common", "top", "custom", "all"}:
            raise ValueError("ports mode must be common, top, custom, or all")
        o["ports"] = mode
        if mode == "custom":
            value = input("[?] Ports (e.g. 80,443 or 1-1000): ").strip()
            if not value:
                raise ValueError("ports are required for custom mode")
            o["custom_ports"] = _port_spec(value, "")
            if not o["custom_ports"]:
                raise ValueError("invalid port specification")
        if mode == "top":
            o["top_n"] = ask_int("[?] Top N [100]: ", 100, 1, 65535)
        o["service"] = input("[?] Service detection? [Y/n]: ").strip().lower() != "n"
        o["udp"] = input("[?] UDP scan? [y/N]: ").strip().lower() == "y"
        timing = input("[?] Timing [-T3]: ").strip() or "-T3"
        if timing not in {"-T0", "-T1", "-T2", "-T3", "-T4", "-T5"}:
            raise ValueError("timing must be -T0 through -T5")
        o["timing"] = timing

    elif spec.name in {"masscan", "rustscan", "naabu"}:
        value = input("[?] Ports [80,443]: ").strip() or "80,443"
        o["ports"] = _port_spec(value, "")
        o["custom_ports"] = o["ports"]
        if not o["ports"]:
            raise ValueError("invalid port specification")
        if spec.name == "masscan":
            o["rate"] = ask_int("[?] Rate [100]: ", 100, 1, 1000000)
        if spec.name == "naabu":
            o["top_n"] = ask_int("[?] Top N [100]: ", 100, 1, 10000)

    elif spec.name in {"gobuster", "ffuf", "feroxbuster", "dirsearch", "wfuzz"}:
        wordlist = input("[?] Wordlist path: ").strip()
        if not wordlist or not os.path.isfile(wordlist):
            raise ValueError("a valid wordlist path is required")
        o["wordlist"] = wordlist
        if spec.name in {"gobuster", "ffuf", "feroxbuster"}:
            o["threads"] = ask_int("[?] Threads [10]: ", 10, 1, 500)
        if spec.name == "gobuster":
            o["extensions"] = input("[?] Extensions [php,html,txt]: ").strip() or "php,html,txt"

    elif spec.name in {"openssl", "sslscan", "testssl.sh"}:
        o["port"] = ask_int("[?] TLS port [443]: ", 443, 1, 65535)

    elif spec.name == "dig":
        record = input("[?] Record [A]: ").strip().upper() or "A"
        allowed = {"A", "AAAA", "MX", "NS", "TXT", "SOA", "CNAME", "PTR", "SRV"}
        if record not in allowed:
            raise ValueError("unsupported DNS record type")
        o["record"] = record

    elif spec.name == "nuclei":
        severity = input("[?] Severity [low,medium,high,critical]: ").strip() or "low,medium,high,critical"
        allowed = {"info", "low", "medium", "high", "critical"}
        levels = [x.strip().lower() for x in severity.split(",") if x.strip()]
        if not levels or any(x not in allowed for x in levels):
            raise ValueError("invalid nuclei severity list")
        o["severity"] = ",".join(dict.fromkeys(levels))
        o["rate"] = ask_int("[?] Rate limit [10]: ", 10, 1, 100000)

    elif spec.name in {"hakrawler", "katana"}:
        o["depth"] = ask_int("[?] Crawl depth [2]: ", 2, 1, 20)

    return o


def run_tool(spec: ToolSpec, target: str, options: Optional[dict] = None, timeout: int = 300):
    if not spec.command or not shutil.which(spec.command):
        return {"tool": spec.name, "status": "unavailable", "stdout": "", "stderr": "tool not installed", "returncode": -1, "command": ""}
    options = options or {}
    cmd = spec.builder(target, options)
    if any(x == "" for x in cmd):
        return {"tool": spec.name, "status": "error", "stdout": "", "stderr": "missing required option", "returncode": -1, "command": shlex.join(cmd)}
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, errors="replace")
        status = "ok" if p.returncode == 0 else "failed"
        return {"tool": spec.name, "status": status, "stdout": p.stdout, "stderr": p.stderr, "returncode": p.returncode, "command": shlex.join(cmd)}
    except subprocess.TimeoutExpired as e:
        out = e.stdout or ""
        err = e.stderr or ""
        if isinstance(out, bytes):
            out = out.decode(errors="replace")
        if isinstance(err, bytes):
            err = err.decode(errors="replace")
        return {"tool": spec.name, "status": "timeout", "stdout": out, "stderr": err or "TIMEOUT", "returncode": -1, "command": shlex.join(cmd)}
    except Exception as e:
        return {"tool": spec.name, "status": "error", "stdout": "", "stderr": str(e), "returncode": -1, "command": shlex.join(cmd)}


def interactive_run(target: str) -> list[dict]:
    print_tool_catalog()
    status = availability()
    print("[1] Run one tool")
    print("[2] Run several tools")
    print("[3] Run all installed tools")
    print("[0] Back")
    choice = input("[?] Select: ").strip()
    if choice == "0": return []
    if choice == "3":
        selected = [t for t in TOOL_LIST if status[t.name]]
    else:
        raw = input("[?] Tool number(s), comma-separated: ").strip()
        selected = []
        for item in raw.split(","):
            if item.strip().isdigit():
                idx = int(item.strip()) - 1
                if 0 <= idx < len(TOOL_LIST): selected.append(TOOL_LIST[idx])
    results = []
    for spec in selected:
        if not status[spec.name]:
            print(f"{C.R}[MISS]{C.X} {spec.name} is not installed")
            results.append(run_tool(spec, target, {}))
            continue
        print()
        print(f"Running {spec.name} — {spec.description}")
        try:
            options = _ask_common(spec)
        except (ValueError, KeyboardInterrupt) as e:
            print(f"{C.Y}[SKIP]{C.X} {spec.name}: {e}")
            results.append({"tool": spec.name, "status": "skipped", "stdout": "", "stderr": str(e), "returncode": -1, "command": ""})
            continue
        result = run_tool(spec, target, options)
        print(f"{C.G if result['status']=='ok' else C.R}[{result['status'].upper()}]{C.X} {spec.name}")
        if result["stdout"]:
            print(result["stdout"][:4000].rstrip())
        if result["stderr"] and result["status"] not in {"ok"}:
            print(result["stderr"][:1000].rstrip())
        results.append(result)
    return results
